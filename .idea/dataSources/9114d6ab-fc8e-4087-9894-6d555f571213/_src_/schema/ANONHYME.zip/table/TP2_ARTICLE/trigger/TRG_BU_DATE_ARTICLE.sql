create trigger TRG_BU_DATE_ARTICLE
	after insert or update
	on TP2_ARTICLE
	for each row
BEGIN
    IF UPDATING
    THEN
      IF :new.DATE_PUBLICATION_ART < :old.DATE_PUBLICATION_ART
      THEN
        raise_application_error(-20052, 'La date de publication doit etre supperieur a la derniere date');
      END IF;
      IF :new.DATE_MISE_A_JOUR_ART < :old.DATE_MISE_A_JOUR_ART
      THEN
        raise_application_error(-20052, 'La date de mise a jour doit etre supperieur a la derniere date');
      END IF;
      IF :new.DATE_PUBLICATION_ART <= :new.DATE_MISE_A_JOUR_ART
      THEN
        raise_application_error(-20052,
                                'La date de modification doit être suppérieur ou égale à la date de publication');
      END IF;
    END IF;
    IF INSERTING
    THEN
      IF :new.DATE_PUBLICATION_ART <= :new.DATE_MISE_A_JOUR_ART
      THEN
        raise_application_error(-20052,
                                'La date de modification doit être suppérieur ou égale à la date de publication');
      END IF;
    END IF;
  END;