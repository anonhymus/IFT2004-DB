create FUNCTION FCT_DISTANCE
  (
    LATITUDE1  IN NUMBER,
    LONGITUDE1 IN NUMBER,
    LATITUDE2  IN NUMBER,
    LONGITUDE2 IN NUMBER
  )
  RETURN DOUBLE PRECISION IS DISTANCE NUMBER;
  DELTA_LON                           REAL;
  DELTA_LAT                           REAL;
  TEMP_A                              REAL;
  TEMP_B                              REAL;
  TEMP_C                              REAL;
  RADIUS                              NUMBER; -- EARTH radius
  BEGIN
    --HAVERSIN FORMULA ...
    -- conversion de degre a radian avec RADIANS
    -- calcul nouveau point delta
    DELTA_LON := (RADIANS(LONGITUDE2) - RADIANS(LONGITUDE1));
    DELTA_LAT := (RADIANS(LATITUDE2) - RADIANS(LATITUDE1));

    -- approximation du rayon de la terre pour la lattitude
    RADIUS := 6378 - 31 * sin(DELTA_LAT);
    TEMP_A := ((sin(DELTA_LAT / 2)) ** 2) +
              (cos(RADIANS(LATITUDE1)) * cos(RADIANS(LATITUDE2)) * (sin(DELTA_LON / 2)) ** 2);
    TEMP_B := 2 * ATAN2(SQRT(TEMP_A), SQRT(1 - TEMP_A));
    DISTANCE := ROUND(RADIUS * TEMP_B, 3);
    RETURN DISTANCE;
  END FCT_DISTANCE;